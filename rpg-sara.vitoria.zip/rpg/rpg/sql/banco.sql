CREATE DATABASE IF NOT EXISTS deus_salve_o_gato
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE deus_salve_o_gato;

CREATE TABLE jogadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    rainha VARCHAR(50) NOT NULL,
    soldados INT NOT NULL,
    povo INT NOT NULL,
    ouro INT NOT NULL,
    pontuacao INT NOT NULL,
    resultado VARCHAR(100) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);