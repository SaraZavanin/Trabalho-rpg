<?php

session_start();

$_SESSION = [];
session_regenerate_id(true);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Deus Salve o Gato</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container">

    <h1>🐱 Deus Salve o Gato 👑</h1>

    <p>Após a morte de seu pai, você é o novo rei de Felíria.</p>
    <p>Suas decisões determinarão o destino do reino.</p>

    <form action="jogo.php" method="POST">
        <label for="nome">Nome do Rei:</label>

        <input
            id="nome"
            type="text"
            name="nome"
            placeholder="Digite o nome do rei"
            maxlength="100"
            required
        >

        <button type="submit">Começar aventura</button>
    </form>

    <a class="link" href="placar.php">🏆 Ver placar</a>

</div>

</body>
</html>
