<?php

require_once "../classes/BancoDados.php";

$banco = new BancoDados();

$jogadores = $banco->buscarPlacar();

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <title>Placar</title>

    <link rel="stylesheet" href="style.css">

</head>

<body>

<div class="container">

    <h1>🏆 Placar dos Reis</h1>

    <table>

        <thead>

        <tr>
            <th>Rei</th>
            <th>Rainha</th>
            <th>Povo</th>
            <th>Soldados</th>
            <th>Ouro</th>
            <th>Pontuação</th>
            <th>Resultado</th>
        </tr>

        </thead>

        <tbody>

        <?php foreach ($jogadores as $jogador): ?>

            <tr>

                <td>
                    <?= htmlspecialchars($jogador["nome"]) ?>
                </td>

                <td>
                    <?= htmlspecialchars($jogador["rainha"]) ?>
                </td>

                <td>
                    <?= $jogador["povo"] ?>
                </td>

                <td>
                    <?= $jogador["soldados"] ?>
                </td>

                <td>
                    <?= $jogador["ouro"] ?>
                </td>

                <td>
                    <?= $jogador["pontuacao"] ?>
                </td>

                <td>
                    <?= htmlspecialchars($jogador["resultado"]) ?>
                </td>

            </tr>

        <?php endforeach; ?>

        </tbody>

    </table>

    <br>

    <a class="button" href="index.php">
        🐱 Novo jogo
    </a>

</div>

</body>
</html>
