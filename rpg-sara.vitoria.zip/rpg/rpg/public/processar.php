<?php

session_start();

require_once "../classes/Personagem.php";
require_once "../classes/Dado.php";
require_once "../classes/Desafio.php";
require_once "../classes/Cena.php";
require_once "../classes/Jogo.php";

if (!isset($_SESSION["personagem"])) {
    header("Location: index.php");
    exit;
}

$personagem = Personagem::fromArray($_SESSION["personagem"]);
$jogo = new Jogo($personagem);
$acao = $_POST["acao"] ?? "";
$cena = (int) ($_SESSION["cena"] ?? 0);

function acaoInvalida(): never
{
    http_response_code(400);
    exit("Ação inválida.");
}

switch ($acao) {

    case "seraphina":
        if ($cena !== 1) acaoInvalida();

        $jogo->escolherRainha("Seraphina");
        $_SESSION["cena"] = 2;
        break;

    case "maeve":
        if ($cena !== 1) acaoInvalida();

        $jogo->escolherRainha("Maeve");
        $_SESSION["cena"] = 2;
        break;

    case "comida":
    case "trabalho":
        if ($cena !== 2) acaoInvalida();

        $jogo->aplicarAcao($acao);
        $_SESSION["cena"] = 3;
        break;

    case "impostos_alto":
    case "impostos_baixo":
        if ($cena !== 3) acaoInvalida();

        $jogo->aplicarAcao($acao);
        $_SESSION["cena"] = 4;
        break;

    case "guerra":
        if ($cena !== 4) acaoInvalida();

        $venceu = $jogo->guerra();
        $_SESSION["guerra_resultado"] = $venceu;
        $_SESSION["cena"] = 5;
        break;

    case "reconstruir":
    case "ignorar":
        if ($cena !== 5) acaoInvalida();

        $jogo->aplicarAcao($acao);
        $_SESSION["cena"] = 6;
        break;

    case "nobre":
    if ($cena !== 6) acaoInvalida();

    $venceu = $jogo->atacarNobre();
    $_SESSION["nobre_resultado"] = $venceu;

    if (!$venceu) {
        $_SESSION["resultado"] = "Morte na batalha contra o nobre";
        header("Location: final.php");
        exit;
    }

    $_SESSION["cena"] = 7;
    break;

    case "destino":
        if ($cena !== 7) acaoInvalida();

        $resultado = $jogo->verificarFinal();

        $finais = [
            "morte1" => "Morte Matada I",
            "morte2" => "Morte Matada II",
            "morte3" => "Morte Morrida"
        ];

        if (isset($finais[$resultado])) {
            $_SESSION["resultado"] = $finais[$resultado];
            header("Location: final.php");
            exit;
        }

        $_SESSION["cena"] = 11;
        break;

    case "caterine":
    case "xavier":
    case "matteo":
        if ($cena !== 11) acaoInvalida();

        $herdeiro = ucfirst($acao);

        if (!in_array($herdeiro, $personagem->getFilhos(), true)) {
            acaoInvalida();
        }

        $_SESSION["herdeiro"] = $herdeiro;
        $_SESSION["resultado"] = "Rei terminou seu reinado e escolheu seu sucessor.";

        header("Location: final.php");
        exit;

    default:
        acaoInvalida();
}

header("Location: jogo.php");
exit;
