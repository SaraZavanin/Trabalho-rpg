<?php

session_start();

require_once "../classes/Personagem.php";
require_once "../classes/Dado.php";
require_once "../classes/Desafio.php";
require_once "../classes/Cena.php";
require_once "../classes/Jogo.php";

if (!isset($_SESSION["personagem"])) {

    $nome = trim($_POST["nome"] ?? "");

    if ($nome === "") {
        header("Location: index.php");
        exit;
    }

    $jogo = new Jogo();
    $jogo->iniciar($nome);

    $_SESSION["cena"] = 1;

} else {

    $personagem = Personagem::fromArray($_SESSION["personagem"]);
    $jogo = new Jogo($personagem);
}

$cena = (int) ($_SESSION["cena"] ?? 1);
$p = $jogo->getPersonagem();

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Deus Salve o Gato</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="game">

    <header>
        <h1>🐱 Deus Salve o Gato</h1>

        <div class="status">
            <span>❤️ Povo: <?= $p->getPovo() ?></span>
            <span>⚔️ Soldados: <?= $p->getSoldados() ?></span>
            <span>🪙 Ouro: <?= $p->getOuro() ?></span>
        </div>
    </header>

<?php if ($cena === 1): ?>

    <h2>👑 Cena 1 — A Coroação</h2>
    <img src="../../img/trono.jpg" alt="A Coroação" class="imagem-cena">

    <p>
        Após a morte de seu pai, você assume o trono de Felíria.
        Como novo rei, sua primeira decisão será escolher sua rainha.
    </p>

    <h3>Escolha sua rainha consorte:</h3>

    <form action="processar.php" method="POST">
        <img src="../../img/seraphina.jpg" alt="A Coroação" class="imagem-cena">
        <button name="acao" value="seraphina">
            👸 Seraphina Moonfall<br>
            +30 povo | +50 soldados | 2 filhos
        </button>

        <img src="../../img/maeve.jpg" alt="A Coroação" class="imagem-cena">
        <button name="acao" value="maeve">
            👸 Maeve Rosewood<br>
            +10 povo | +100 soldados | 1 filho
        </button>
    </form>

<?php elseif ($cena === 2): ?>

    <h2>🍞 Cena 2 — O Povo está com fome</h2>
    <img src="../../img/sudito.jpg" alt="fome" class="imagem-cena">

    <p>Um súdito desesperado chega ao castelo:</p>

    <blockquote>"Majestade! O povo está passando fome!"</blockquote>

    <form action="processar.php" method="POST">
        <button name="acao" value="comida">🍞 Distribuir comida</button>
        <button name="acao" value="trabalho">⛏️ Mandar o povo trabalhar mais</button>
    </form>

<?php elseif ($cena === 3): ?>

    <h2>💰 Cena 3 — Os Impostos</h2>
    <img src="../../img/bispo.jpg" alt="A decisao" class="imagem-cena">

    <p>O conselheiro pergunta o que deve ser feito com os impostos.</p>

    <form action="processar.php" method="POST">
        <button name="acao" value="impostos_alto">💰 Aumentar impostos</button>
        <button name="acao" value="impostos_baixo">🪙 Baixar impostos</button>
    </form>

<?php elseif ($cena === 4): ?>

    <h2>⚔️ Cena 4 — Guerra!</h2>
    <img src="../../img/guerra.jpg" alt="guerra" class="imagem-cena">

    <p>Um reino vizinho declarou guerra contra Felíria.</p>
    <p>Você irá pessoalmente para a batalha?</p>

    <form action="processar.php" method="POST">
        <button name="acao" value="guerra">⚔️ Ir para a batalha</button>
    </form>

<?php elseif ($cena === 5): ?>

    <h2> Depois da Guerra</h2>

    <?php if (isset($_SESSION["guerra_resultado"])): ?>

        <?php if ($_SESSION["guerra_resultado"] === true): ?>

            <div class="mensagem venceu">
                🏆 Você venceu a guerra!
                <p>Seu reino conseguiu superar o conflito.</p>
            </div>

        <?php else: ?>

            <div class="mensagem perdeu">
                😔 Você perdeu a guerra.
                <p>O reino sofreu uma derrota.</p>
            </div>

        <?php endif; ?>

        <?php unset($_SESSION["guerra_resultado"]); ?>

    <?php endif; ?>

    <h2>🔥 Cena 5 — O Incêndio</h2> 
    <img src="../../img/vilafogo.jpg" alt="incendio" class="imagem-cena">

    <p>Casas da vila pegaram fogo e muitas famílias ficaram sem moradia.</p>

    <form action="processar.php" method="POST">
        <button name="acao" value="reconstruir">🏠 Reconstruir as casas</button>
        <button name="acao" value="ignorar">🚫 Deixar o povo resolver</button>
    </form>

<?php elseif ($cena === 6): ?>

    <h2>🗡️ Cena 6 — O Nobre</h2>
    <img src="../../img/trono.jpg" alt="trono" class="imagem-cena">

    <p>Um poderoso nobre invade a sala do trono e tenta assassiná-lo!</p>

    <form action="processar.php" method="POST">
        <button name="acao" value="nobre">⚔️ Enfrentar o nobre</button>
    </form>

<?php elseif ($cena === 7): ?>

    <h2>🏰 Cena 7 — O Destino do Reino</h2>

    <p>Seu conselheiro traz um relatório completo sobre seu reinado.</p>
    <p>Agora chegou o momento de descobrir qual será seu destino.</p>

    <form action="processar.php" method="POST">
        <button name="acao" value="destino">🔮 Descobrir meu destino</button>
    </form>

<?php elseif ($cena === 11): ?>

    <h2>👑 Cena 11 — O Próximo Herdeiro</h2>

    <p>Seu reinado está chegando ao fim. Agora você precisa escolher seu sucessor.</p>

    <?php
        $imagens = [
            "maeve" => "mateo.jpg",
            "sephina" => "fsephina.jpg"
        ];
    ?>

    <form action="processar.php" method="POST">

        <?php foreach ($p->getFilhos() as $filho): ?>

            <?php
                $chave = strtolower($filho);
                $imagem = $imagens[$chave] ?? "trono.jpg";
            ?>

            <div class="herdeiro">

                <img
                    src="../../img/<?= htmlspecialchars($imagem) ?>"
                    alt="<?= htmlspecialchars($filho) ?>"
                    class="imagem-cena"
                >

                <button name="acao" value="<?= htmlspecialchars($chave) ?>">
                    👑 <?= htmlspecialchars($filho) ?>
                </button>

            </div>

        <?php endforeach; ?>

    </form>

<?php else: ?>

    <h2>Erro: cena inválida</h2>

    <a class="button" href="index.php">Voltar ao início</a>

<?php endif; ?>
    </form>

    

</div>

</body>
</html>
