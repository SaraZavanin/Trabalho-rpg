<?php

session_start();

require_once "../classes/Personagem.php";
require_once "../classes/BancoDados.php";

if (!isset($_SESSION["personagem"])) {
    header("Location: index.php");
    exit;
}

$p = Personagem::fromArray($_SESSION["personagem"]);
$resultado = $_SESSION["resultado"] ?? "Fim da aventura";

if (empty($_SESSION["resultado_salvo"])) {
    $banco = new BancoDados();

    $banco->salvarResultado(
        $p->getNome(),
        $p->getRainha(),
        $p->getSoldados(),
        $p->getPovo(),
        $p->getOuro(),
        $p->pontuacao(),
        $resultado
    );

    $_SESSION["resultado_salvo"] = true;
}

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <title>Fim — Deus Salve o Gato</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<div class="container final">

<?php if ($resultado === "Morte Matada I"): ?>

    <h1>☠️ Morte Matada I</h1>
    <p>Uma conspiração tomou conta do castelo. O rei possuía riquezas e um poderoso exército, tornando-se uma ameaça para os nobres.</p>
    <p>Durante a madrugada, assassinos invadiram seus aposentos.</p>

<?php elseif ($resultado === "Morte Matada II"): ?>

    <h1>☠️ Morte Matada II</h1>
    <p>O povo perdeu completamente a confiança no rei.</p>
    <p>Uma multidão invadiu o castelo e colocou fim ao seu reinado.</p>

<?php elseif ($resultado === "Morte Morrida"): ?>

    <h1>🕊️ Morte Morrida</h1>
    <p>Depois de muitos anos governando Felíria, o rei chegou à velhice.</p>
    <p>Cercado por sua família, morreu tranquilamente, lembrado como um bom rei.</p>

<?php elseif ($resultado === "Morte na batalha contra o nobre"): ?>

    <h1>💀 O rei morreu</h1>
    <p>O nobre conseguiu atingir o rei. O golpe foi fatal.</p>

<?php else: ?>

    <h1>👑 O Reinado Terminou</h1>
    <p>O rei terminou seu reinado e escolheu seu sucessor.</p>

    <h2>
        Novo herdeiro:
        <?= htmlspecialchars($_SESSION["herdeiro"] ?? "") ?>
    </h2>

<?php endif; ?>

<hr>

<h2>📜 Resultado do Reinado</h2>

<p>👑 Rei: <?= htmlspecialchars($p->getNome()) ?></p>
<p>👸 Rainha: <?= htmlspecialchars($p->getRainha()) ?></p>
<p>❤️ Pontos com o povo: <?= $p->getPovo() ?></p>
<p>⚔️ Soldados: <?= $p->getSoldados() ?></p>
<p>🪙 Ouro: <?= $p->getOuro() ?></p>
<p>🏆 Pontuação: <?= $p->pontuacao() ?></p>

<br>

<a class="button" href="index.php">🔄 Jogar novamente</a>
<a class="button" href="placar.php">🏆 Ver placar</a>

</div>

</body>
</html>
