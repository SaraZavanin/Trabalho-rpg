<?php

class Database
{
    private string $host = "localhost";
    private string $database = "deus_salve_o_gato";
    private string $user = "root";
    private string $password = "";

    public function conectar(): PDO
    {
        try {

            $pdo = new PDO(
                "mysql:host={$this->host};dbname={$this->database};charset=utf8mb4",
                $this->user,
                $this->password
            );

            $pdo->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );

            return $pdo;

        } catch (PDOException $e) {

            die(
                "Erro ao conectar ao banco de dados: "
                . $e->getMessage()
            );
        }
    }
}
