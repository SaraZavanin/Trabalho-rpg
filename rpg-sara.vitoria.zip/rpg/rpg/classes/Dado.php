<?php

class Dado
{
    private int $minimo;
    private int $maximo;

    public function __construct(int $minimo = 1, int $maximo = 10)
    {
        $this->minimo = $minimo;
        $this->maximo = $maximo;
    }

    public function rolar(): int
    {
        return random_int($this->minimo, $this->maximo);
    }
}
