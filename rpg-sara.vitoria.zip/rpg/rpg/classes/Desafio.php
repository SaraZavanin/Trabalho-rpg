<?php

class Desafio
{
    private string $nome;
    private int $dado;
    private bool $venceu;

    public function __construct(string $nome)
    {
        $this->nome = $nome;
        $this->dado = 0;
        $this->venceu = false;
    }

    public function executar(): bool
    {
        $dado = new Dado();
        $this->dado = $dado->rolar();

        if ($this->nome === "Ataque do Nobre") {
            $this->venceu = $this->dado >= 8;
        } else {
            $this->venceu = $this->dado > 6;
        }

    return $this->venceu;
}


    public function getDado(): int
    {
        return $this->dado;
    }

    public function venceu(): bool
    {
        return $this->venceu;
    }

    public function getNome(): string
    {
        return $this->nome;
    }
}
