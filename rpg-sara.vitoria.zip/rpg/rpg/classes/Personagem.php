<?php

class Personagem
{
    private string $nome;
    private int $soldados;
    private int $povo;
    private int $ouro;
    private string $rainha;
    private array $filhos;

    public function __construct(string $nome)
    {
        $this->nome = trim($nome);
        $this->soldados = 200;
        $this->povo = 50;
        $this->ouro = 1000;
        $this->rainha = "";
        $this->filhos = [];
    }

    public function escolherRainha(string $rainha): void
    {
        if (!in_array($rainha, ["Seraphina", "Maeve"], true)) {
            throw new InvalidArgumentException("Rainha inválida.");
        }

        $this->rainha = $rainha;

        if ($rainha === "Seraphina") {
            $this->alterarPovo(30);
            $this->alterarSoldados(50);
            $this->filhos = ["Caterine", "Xavier"];
        } else {
            $this->alterarPovo(10);
            $this->alterarSoldados(100);
            $this->filhos = ["Matteo"];
        }
    }

    public function alterarSoldados(int $valor): void
    {
        $this->soldados = max(0, $this->soldados + $valor);
    }

    public function alterarPovo(int $valor): void
    {
        $this->povo = max(0, $this->povo + $valor);
    }

    public function alterarOuro(int $valor): void
    {
        $this->ouro = max(0, $this->ouro + $valor);
    }

    public function getNome(): string { return $this->nome; }
    public function getSoldados(): int { return $this->soldados; }
    public function getPovo(): int { return $this->povo; }
    public function getOuro(): int { return $this->ouro; }
    public function getRainha(): string { return $this->rainha; }
    public function getFilhos(): array { return $this->filhos; }

    public function pontuacao(): int
    {
        return $this->povo + $this->soldados + $this->ouro;
    }

    public function toArray(): array
    {
        return [
            "nome" => $this->nome,
            "soldados" => $this->soldados,
            "povo" => $this->povo,
            "ouro" => $this->ouro,
            "rainha" => $this->rainha,
            "filhos" => $this->filhos
        ];
    }

    public static function fromArray(array $dados): Personagem
    {
        if (!isset($dados["nome"])) {
            throw new InvalidArgumentException("Dados do personagem inválidos.");
        }

        $personagem = new self((string) $dados["nome"]);

        foreach (["soldados", "povo", "ouro"] as $campo) {
            if (isset($dados[$campo])) {
                $personagem->{$campo} = (int) $dados[$campo];
            }
        }

        if (isset($dados["rainha"])) {
            $personagem->rainha = (string) $dados["rainha"];
        }

        if (isset($dados["filhos"]) && is_array($dados["filhos"])) {
            $personagem->filhos = array_values($dados["filhos"]);
        }

        return $personagem;
    }
}
