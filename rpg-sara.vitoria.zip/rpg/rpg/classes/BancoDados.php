<?php

require_once __DIR__ . "/../config/Database.php";

class BancoDados
{
    private PDO $pdo;

    public function __construct()
    {
        $database = new Database();
        $this->pdo = $database->conectar();
    }

    public function salvarResultado(
        string $nome,
        string $rainha,
        int $soldados,
        int $povo,
        int $ouro,
        int $pontuacao,
        string $resultado
    ): void {

        $sql = "INSERT INTO jogadores
                (nome, rainha, soldados, povo, ouro, pontuacao, resultado)
                VALUES
                (:nome, :rainha, :soldados, :povo, :ouro, :pontuacao, :resultado)";

        $stmt = $this->pdo->prepare($sql);

        $stmt->execute([
            ":nome" => $nome,
            ":rainha" => $rainha,
            ":soldados" => $soldados,
            ":povo" => $povo,
            ":ouro" => $ouro,
            ":pontuacao" => $pontuacao,
            ":resultado" => $resultado
        ]);
    }

    public function buscarPlacar(): array
    {
        $sql = "SELECT * FROM jogadores
                ORDER BY pontuacao DESC";

        return $this->pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }
}
