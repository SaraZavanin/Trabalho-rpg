<?php

class Jogo
{
    private ?Personagem $personagem;

    public function __construct(?Personagem $personagem = null)
    {
        $this->personagem = $personagem;
    }

    public function iniciar(string $nome): void
    {
        $nome = trim($nome);

        if ($nome === "") {
            throw new InvalidArgumentException("O nome do rei é obrigatório.");
        }

        $this->personagem = new Personagem($nome);
        $this->salvarSessao();
    }

    public function escolherRainha(string $rainha): void
    {
        $this->garantirPersonagem();
        $this->personagem->escolherRainha($rainha);
        $this->salvarSessao();
    }

    public function salvarSessao(): void
    {
        if ($this->personagem !== null) {
            $_SESSION["personagem"] = $this->personagem->toArray();
        }
    }

    public function getPersonagem(): Personagem
    {
        $this->garantirPersonagem();
        return $this->personagem;
    }

    public function aplicarAcao(string $acao): void
    {
        $this->garantirPersonagem();

        switch ($acao) {
            case "comida":
                $this->personagem->alterarPovo(30);
                $this->personagem->alterarSoldados(50);
                $this->personagem->alterarOuro(-50);
                break;

            case "trabalho":
                $this->personagem->alterarPovo(-20);
                $this->personagem->alterarOuro(20);
                break;

            case "impostos_alto":
                $this->personagem->alterarPovo(-10);
                $this->personagem->alterarOuro(70);
                break;

            case "impostos_baixo":
                $this->personagem->alterarPovo(10);
                $this->personagem->alterarSoldados(30);
                break;

            case "reconstruir":
                $this->personagem->alterarPovo(50);
                $this->personagem->alterarOuro(-80);
                break;

            case "ignorar":
                $this->personagem->alterarPovo(-70);
                break;

            default:
                throw new InvalidArgumentException("Ação inválida.");
        }

        $this->salvarSessao();
    }

    public function guerra(): bool
    {
        $this->garantirPersonagem();

        $desafio = new Desafio("Guerra");
        $venceu = $desafio->executar();

        $_SESSION["dado"] = $desafio->getDado();

        if ($venceu) {
            $this->personagem->alterarSoldados(100);
            $this->personagem->alterarPovo(50);
        } else {
            $this->personagem->alterarSoldados(-100);
            $this->personagem->alterarPovo(-20);
        }

        $this->salvarSessao();
        return $venceu;
    }

    public function atacarNobre(): bool
    {
        $this->garantirPersonagem();

        $desafio = new Desafio("Ataque do Nobre");
        $venceu = $desafio->executar();

        $_SESSION["dado"] = $desafio->getDado();

        if ($venceu) {
            $this->personagem->alterarPovo(20);
            $this->salvarSessao();
        }

        return $venceu;
    }

    public function verificarFinal(): string
    {
        $this->garantirPersonagem();
        $p = $this->personagem;

        if (
            $p->getSoldados() > 300 &&
            $p->getOuro() > 1000 &&
            $p->getRainha() === "Maeve"
        ) {
            return "morte1";
        }

        if ($p->getPovo() <= 10) {
            return "morte2";
        }

        if (
            $p->getPovo() > 70 &&
            $p->getRainha() === "Seraphina"
        ) {
            return "morte3";
        }

        return "sucessao";
    }

    private function garantirPersonagem(): void
    {
        if ($this->personagem === null) {
            throw new RuntimeException("Personagem não iniciado.");
        }
    }
}
